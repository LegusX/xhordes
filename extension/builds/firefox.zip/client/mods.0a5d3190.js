import{S as s,i as e,s as t}from"./client.ebe26285.js";export default class extends s{constructor(s){super(),e(this,s,null,null,t,{})}}
